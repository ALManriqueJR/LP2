﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnContaNumeros_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (var item in rctxtFrase.Text)
            {
                if (char.IsNumber(item))
                {
                    cont++;
                }
            }

            MessageBox.Show("n de numeros: " + cont);
        }

        private void BtnContaLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;

            for (int i = 0; i < rctxtFrase.Text.Length; i++)
            {
                if (char.IsLetter(rctxtFrase.Text[i]))
                {
                    cont++;
                }
            }
            MessageBox.Show($"n de caracteres: {cont}");
        }

        private void BtnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            if (rctxtFrase.Text != "")
            {
                while (!(char.IsWhiteSpace(rctxtFrase.Text[posicao])))
                {
                    posicao++;
                }

                MessageBox.Show($"n de caracteres: {posicao+1}");
            }
            else
            {
                MessageBox.Show("Texto em branco");
            }



        }
    }
}
