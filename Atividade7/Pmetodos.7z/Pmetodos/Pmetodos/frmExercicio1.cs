﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void CopiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Escolheu copiar");
        }

        private void ColarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Escolheu colar");
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                MessageBox.Show("Form ja ativo");
                //Application.OpenForms["frmExercicio2"].BringToFront();
                Application.OpenForms["frmExercicio2"].Activate(); //FAZ A MSM COISA
            }
            else
            {
                frmExercicio2 frm2 = new frmExercicio2();
                frm2.MdiParent = this;
                frm2.WindowState = FormWindowState.Maximized;
                frm2.Show();
            }
        }

        private void Exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                MessageBox.Show("form ja ativo");
                //application.openforms["frmexercicio2"].bringtofront();
                Application.OpenForms["frmexercicio3"].Activate(); //faz a msm coisa
            }
            else
            {
                frmExercicio3 frm3 = new frmExercicio3();
                frm3.MdiParent = this;
                frm3.WindowState = FormWindowState.Maximized;
                frm3.Show();
            }
        }

        private void Exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form ja ativo");
                //Application.OpenForms["frmExercicio2"].BringToFront();
                Application.OpenForms["frmExercicio4"].Activate(); //FAZ A MSM COISA
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.MdiParent = this;
                frm4.WindowState = FormWindowState.Maximized;
                frm4.Show();
            }
        }

        private void Exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form ja ativo");
                //Application.OpenForms["frmExercicio2"].BringToFront();
                Application.OpenForms["frmExercicio5"].Activate(); //FAZ A MSM COISA
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.MdiParent = this;
                frm5.WindowState = FormWindowState.Maximized;
                frm5.Show();
            }
        }

        private void editorDeTextosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("notepad.exe");
        }

        private void calculadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("calc.exe");
        }
    }
}
