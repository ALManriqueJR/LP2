﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = 0;
            num2 = 0;

            if (!(int.TryParse(txtNum1.Text, out num1) )|| !(int.TryParse(txtNum2.Text, out num2)))
            {
                MessageBox.Show("Numeros inválidos");
            }
            else
            {

                if ((num1 <= 0) || (num2 <= 0) || (num1 > num2))
                {
                    MessageBox.Show("Numero 1 precisa ser menor que o Numero 2.");
                }
                else
                {
                    Random rd = new Random();
                    int aleatorio = rd.Next(num1,num2);
                    MessageBox.Show("Numero aleatório é : " + aleatorio);
                }
            }


        }
    }
}
