﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class FrmPcalc : Form
    {
        double vnum1, vnum2, res; //globais


        public FrmPcalc()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = null;
            //txtNum1.Text = "";

            txtNum2.Clear();

            txtResult.Text = String.Empty;

            txtNum1.Focus();

        }



        private void BtnSair_Click(object sender, EventArgs e)
        {
            DialogResult click = MessageBox.Show("Deseja mesmo sair?", "Saindo...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (click == DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            res = vnum1 + vnum2;
            txtResult.Text = res.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtNum1.Focus();
        }

        private void BtnSubtrair_Click(object sender, EventArgs e)
        {
            res = vnum1 - vnum2;
            txtResult.Text = res.ToString();
        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
            res = vnum1 * vnum2;
            txtResult.Text = res.ToString();
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (vnum2 != 0)
            {
                res = vnum1 / vnum2;
                txtResult.Text = res.ToString();
            }
            else
            {
                MessageBox.Show("Impossivel divisão por 0 !","Erro:",MessageBoxButtons.OK,MessageBoxIcon.Stop);
                txtNum2.Focus();
            }
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out vnum1))
            {
                MessageBox.Show("Numero invalido");
                txtNum1.Focus();
            }
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out vnum2))
            {
                MessageBox.Show("Numero invalido");
                txtNum2.Focus();
            }
        }

    }
}
