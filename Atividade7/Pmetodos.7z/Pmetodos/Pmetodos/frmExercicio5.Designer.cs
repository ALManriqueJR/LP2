﻿namespace Pmetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSegundoNum = new System.Windows.Forms.Label();
            this.lblPrimeiroNum = new System.Windows.Forms.Label();
            this.btnSortear = new System.Windows.Forms.Button();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblSegundoNum
            // 
            this.lblSegundoNum.AutoSize = true;
            this.lblSegundoNum.Location = new System.Drawing.Point(273, 187);
            this.lblSegundoNum.Name = "lblSegundoNum";
            this.lblSegundoNum.Size = new System.Drawing.Size(90, 13);
            this.lblSegundoNum.TabIndex = 13;
            this.lblSegundoNum.Text = "Segundo Numero";
            // 
            // lblPrimeiroNum
            // 
            this.lblPrimeiroNum.AutoSize = true;
            this.lblPrimeiroNum.Location = new System.Drawing.Point(273, 129);
            this.lblPrimeiroNum.Name = "lblPrimeiroNum";
            this.lblPrimeiroNum.Size = new System.Drawing.Size(84, 13);
            this.lblPrimeiroNum.TabIndex = 12;
            this.lblPrimeiroNum.Text = "Primeiro Numero";
            // 
            // btnSortear
            // 
            this.btnSortear.Location = new System.Drawing.Point(290, 251);
            this.btnSortear.Name = "btnSortear";
            this.btnSortear.Size = new System.Drawing.Size(194, 62);
            this.btnSortear.TabIndex = 9;
            this.btnSortear.Text = "Realizar Sorteio";
            this.btnSortear.UseVisualStyleBackColor = true;
            this.btnSortear.Click += new System.EventHandler(this.BtnSortear_Click);
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(393, 180);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 8;
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(393, 126);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 7;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.lblSegundoNum);
            this.Controls.Add(this.lblPrimeiroNum);
            this.Controls.Add(this.btnSortear);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.MaximizeBox = false;
            this.Name = "frmExercicio5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSegundoNum;
        private System.Windows.Forms.Label lblPrimeiroNum;
        private System.Windows.Forms.Button btnSortear;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum1;
    }
}