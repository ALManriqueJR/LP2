﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemover_Click(object sender, EventArgs e)
        {
            int posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            //a         //ss
            //casa      //assessoria

            while (posicao >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) 
                    + txtPalavra2.Text.Substring(posicao + txtPalavra1.Text.Length, txtPalavra2.Text.Length - posicao - txtPalavra1.Text.Length);


                posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }

        }

        private void BtnRemover2_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void BtnInverter_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray(); // transformou a string em um vetor de char

            txtPalavra2.Text = "";

            Array.Reverse(vetor);

            foreach (var item in vetor)
            {
                txtPalavra2.Text += item;
            }

            //OU txtPalavra2.Text = new string(vetor);

        }
    }
}
