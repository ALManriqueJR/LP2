﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class formImc : Form
    {

        Double altura, peso;
        Boolean flagP, flagA;

        public formImc()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            DialogResult click = MessageBox.Show("Deseja mesmo sair?", "Saindo...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (click == DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskAltura.Text = mskPeso.Text = txtImc.Text = "";
            mskPeso.Focus();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            Double res;

            if (flagP)
            {
                MessageBox.Show("Peso esta inválido!");
                mskPeso.Focus();

            }
            else if (flagA)
            {
                MessageBox.Show("Altura esta inválida!");
                mskAltura.Focus();
            }
            else{
                res = Math.Round(this.peso / Math.Pow(this.altura, 2));
                txtImc.Text = res.ToString("N1");

                if (res < 18.5)
                {
                    txtImc.Text += " = Magreza";
                }
                else if (res <= 24.9)
                {
                    txtImc.Text += " = Normal";
                }
                else if (res <= 29.9)
                {
                    txtImc.Text += " = Sobrepeso";
                }
                else if (res <= 24.9)
                {
                    txtImc.Text += " = Obesidade";
                }
                else
                {
                    txtImc.Text += " = Obesidade Mórbida";
                }
            }
        }

        private void MskPeso_Validated(object sender, EventArgs e)
        {

            errProv1.SetError(mskPeso, "");

            if (!Double.TryParse(mskPeso.Text, out this.peso) || this.peso <= 0 || this.peso > 500)
            {
                errProv1.SetError(mskPeso, "Peso inválido \nMáx. 500kg");
                flagP = true;
            }
            else
            {
                flagP = false;
            }
        }

        private void MskAltura_Validated(object sender, EventArgs e)
        {

            errProv2.SetError(mskAltura, "");

            if (!Double.TryParse(mskAltura.Text, out this.altura) || this.altura <= 0 || this.altura > 2.5)
            {
                errProv1.SetError(mskAltura, "Altura inválida \n Máx. 2,5 m");
                flagA = true;
            }
            else
            {
                flagA = false;
            }
        }
    }
}
